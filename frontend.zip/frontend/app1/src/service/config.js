export const config ={
    studentServerBaseURL : 'http://localhost:4002',
    teacherServerBaseURL : 'http://localhost:4000',
    cocoServerBaseURL : 'http://localhost:4003',
    adminServerBaseURL : 'http://localhost:4001',
}