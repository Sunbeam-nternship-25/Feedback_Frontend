import { ToastContainer } from 'react-toastify'
import StudentLogin from './pages/Studentlogin/studentlogin'
import CocoLogin from './pages/cocologin/cocologin'
import AdminLogin from './pages/adminlogin/adminlogin'
import TeacherLogin from './pages/teacherlogin/teacherlogin'

import { Route, Routes } from 'react-router-dom'
import StudentRegister from './pages/studentregister/StudentRegister'
import TeacherRegister from './pages/teacherRegister/teacherRegister'
import CocoRegister from './pages/cocoregister/cocoregister'
import StudentDashboard from './pages/StudentDashboard/dashboard'

function App() {
  return (
    <div>
      <Routes>
        <Route path="/" element={<StudentLogin />} />
        <Route path="/cocologin" element={<CocoLogin />} />
        <Route path="/teacherlogin" element={<TeacherLogin />} />
        <Route path="/adminlogin" element={<AdminLogin />} />
        <Route path="/studentregister" element={<StudentRegister />} />
        <Route path="/teacherRegister" element={<TeacherRegister />} />
        <Route path="/cocoregister" element={<CocoRegister />} />
        <Route path="/studentDashboard" element={<StudentDashboard />} />
       </Routes>
      <ToastContainer />
    </div>
  )
}

export default App
